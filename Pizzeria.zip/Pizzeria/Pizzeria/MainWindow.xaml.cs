﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pizzeria
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            IngredientsSlider.ValueChanged += IngredientsSlider_ValueChanged;
        }

        // Actualiza el número de ingredientes mostrados
        private void IngredientsSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            IngredientCountText.Text = IngredientsSlider.Value.ToString();
        }

        // Calcula el precio total de la pizza
        private void CalculatePrice_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double totalPrice = 0;

                // Obtener precio base según el tamaño de la pizza
                if (PizzaSizeComboBox.SelectedItem is ComboBoxItem selectedSize)
                {
                    totalPrice = Convert.ToDouble(selectedSize.Tag);
                }
                else
                {
                    MessageBox.Show("Por favor, selecciona un tamaño de pizza.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Agregar costo por ingredientes adicionales (solo para mediana y grande)
                if (PizzaSizeComboBox.SelectedIndex != 0) // No aplica a individual
                {
                    double extraIngredients = IngredientsSlider.Value;
                    totalPrice += (extraIngredients * 20);
                }

                // Agregar queso extra (solo para mediana y grande)
                if (ExtraCheeseCheckBox.IsChecked == true && PizzaSizeComboBox.SelectedIndex != 0)
                {
                    totalPrice += 15;
                }
                else if (ExtraCheeseCheckBox.IsChecked == true)
                {
                    MessageBox.Show("El queso extra solo está disponible para pizzas medianas y grandes.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                    ExtraCheeseCheckBox.IsChecked = false;
                }

                // Agregar masa super delgada (solo para grande)
                if (ThinCrustCheckBox.IsChecked == true && PizzaSizeComboBox.SelectedIndex == 2) // 2 = Grande
                {
                    totalPrice += 40;
                }
                else if (ThinCrustCheckBox.IsChecked == true)
                {
                    MessageBox.Show("La masa super delgada solo está disponible para pizzas grandes.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                    ThinCrustCheckBox.IsChecked = false;
                }

                // Mostrar el total en la UI
                TotalPriceTextBlock.Text = $"Total: {totalPrice:0.00} MXN";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}