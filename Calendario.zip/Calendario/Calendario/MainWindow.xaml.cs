﻿using System.ComponentModel;
using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calendario
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private DateTime _fechaseleccionada;
        public DateTime FechaSeleccionada
        {
            get { return _fechaseleccionada; }
            set
            {
                _fechaseleccionada = value;
                OnPropertyChanged(nameof(FechaSeleccionada));
                OnPropertyChanged(nameof(DiaSemana));
                OnPropertyChanged(nameof(Mes));
                OnPropertyChanged(nameof(Dia));
                OnPropertyChanged(nameof(Año));
            }
        }

        public string DiaSemana => FechaSeleccionada.ToString("dddd", new CultureInfo("es-ES"));
        public string Mes => FechaSeleccionada.ToString("MMMM", new CultureInfo("es-ES"));
        public string Dia => FechaSeleccionada.Day.ToString();
        public string Año => FechaSeleccionada.Year.ToString();
        public MainWindow()
        {
            InitializeComponent();
            FechaSeleccionada = DateTime.Today;
            DataContext = this;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}